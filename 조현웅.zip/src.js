const statusText = document.getElementById('status__text')

let map
let mapContainer
let ps
let position

let prevInfoWindow
let InfoWindowClicked = false

function getLocation(callback) {
  statusText.innerHTML = '위치 정보 가져오는중'

  var promise = new Promise(function (resolve, reject) {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function (position) {
        resolve([position.coords.latitude, position.coords.longitude])
      })
    } else {
      reject('Unknown')
    }
  })

  return promise
}

const createMap = async (lat, long) => {
  ;(mapContainer = document.getElementById('map')), // 지도를 표시할 div
    (mapOption = {
      center: new kakao.maps.LatLng(lat, long), // 지도의 중심좌표
      level: 4 // 지도의 확대 레벨
    })
  map = new kakao.maps.Map(mapContainer, mapOption)
  ps = new kakao.maps.services.Places()
  kakao.maps.load(() => {
    const category = ['CS2', 'FD6', 'CE7']

    const callback = (result, status, pagination) => {
      if (status === kakao.maps.services.Status.OK) {
        result.map((currentStore) => {
          const markerPosition = new kakao.maps.LatLng(
            parseFloat(currentStore.y),
            parseFloat(currentStore.x)
          )
          const marker = new kakao.maps.Marker({
            map: map,
            averageCenter: true,
            minLevel: 6,
            disableClickZoom: false,
            position: markerPosition
          })
          const infoWindow = new kakao.maps.InfoWindow({
            removable: true,
            content: `이름: ${currentStore.place_name}<br/>주소: <a href="https://map.kakao.com/?map_type=TYPE_MAP&itemId=${currentStore.id}" style="color:blue" target="_blank">${currentStore.address_name}</a>` // 인포윈도우에 표시할 내용
          })
          kakao.maps.event.addListener(marker, 'click', () => {
            infoWindow.open(map, marker)
          })
        })
        if (pagination.hasNextPage) {
          return pagination.nextPage()
        }
      }
    }

    category.forEach((currentCategory) => {
      ps.categorySearch(currentCategory, callback, {
        location: new kakao.maps.LatLng(lat, long),
        radius: 1000
      })
    })
  })
}

const locationPromise = getLocation()
locationPromise
  .then(function (loc) {
    position = loc
    statusText.innerHTML = '위치 가져오기 성공'
    createMap(loc[0], loc[1])
  })
  .catch(function (err) {
    statusText.innerHTML = '위치 가져오기 실패'
  })
